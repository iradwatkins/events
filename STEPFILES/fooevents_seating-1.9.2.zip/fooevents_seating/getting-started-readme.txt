
README

------------------

Plugin Folder Location

The plugin folder are located in the folder 'PLUGIN_FILES'.

------------------

Getting started 

Please refer to the following help section to get started: 
https://help.fooevents.com/docs/fooevents-seating/

------------------

Online Documentation

The documentation will assist with the installation and setup of FooEvents:
https://help.fooevents.com/

------------------

Frequently Asked Questions

Find all of the answers to commonly asked questions about FooEvents:
https://help.fooevents.com/docs/frequently-asked-questions/
 
------------------

Visit FooEvents.com for more information.