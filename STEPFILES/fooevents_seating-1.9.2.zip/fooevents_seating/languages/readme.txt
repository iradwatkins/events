1. Please use default.po for your translations

2. Use the text domain fooevents-seating. E.g fooevents-seating-en_CA.po

3. Place language files in this directory