// ====================================
// THEATRE SEATING COMPONENTS
// ====================================

// SVG Seat Designs
const SEAT_DESIGNS = {
    // Standard theatre seat (top-down view)
    STANDARD: `
        <svg width="40" height="40" viewBox="0 0 40 40" xmlns="http://www.w3.org/2000/svg">
            <!-- Seat back -->
            <rect x="5" y="5" width="30" height="8" rx="2" fill="#8B4513" stroke="#5D2E0C" stroke-width="1"/>
            <!-- Seat cushion -->
            <rect x="5" y="15" width="30" height="20" rx="3" fill="#A0522D" stroke="#5D2E0C" stroke-width="1"/>
            <!-- Armrests -->
            <rect x="3" y="15" width="3" height="15" rx="1" fill="#6B3410"/>
            <rect x="34" y="15" width="3" height="15" rx="1" fill="#6B3410"/>
        </svg>
    `,

    // VIP recliner seat
    VIP_RECLINER: `
        <svg width="45" height="45" viewBox="0 0 45 45" xmlns="http://www.w3.org/2000/svg">
            <!-- Seat back (larger) -->
            <rect x="5" y="3" width="35" height="10" rx="3" fill="#8B008B" stroke="#4B0082" stroke-width="1.5"/>
            <!-- Seat cushion (padded look) -->
            <rect x="5" y="15" width="35" height="25" rx="4" fill="#9932CC" stroke="#4B0082" stroke-width="1.5"/>
            <!-- Armrests (wider) -->
            <rect x="2" y="15" width="4" height="20" rx="2" fill="#6A0DAD"/>
            <rect x="39" y="15" width="4" height="20" rx="2" fill="#6A0DAD"/>
            <!-- Cup holder indicator -->
            <circle cx="42" cy="38" r="2" fill="#FFD700" stroke="#DAA520" stroke-width="0.5"/>
        </svg>
    `,

    // Accessible/Wheelchair space
    WHEELCHAIR: `
        <svg width="45" height="45" viewBox="0 0 45 45" xmlns="http://www.w3.org/2000/svg">
            <rect x="5" y="5" width="35" height="35" rx="3" fill="#4169E1" stroke="#000080" stroke-width="1" stroke-dasharray="3,2"/>
            <text x="22.5" y="28" text-anchor="middle" fill="white" font-size="20" font-weight="bold">♿</text>
        </svg>
    `,

    // Love seat (2-seater)
    LOVESEAT: `
        <svg width="75" height="40" viewBox="0 0 75 40" xmlns="http://www.w3.org/2000/svg">
            <!-- Combined seat back -->
            <rect x="5" y="5" width="65" height="8" rx="2" fill="#8B4513" stroke="#5D2E0C" stroke-width="1"/>
            <!-- Left cushion -->
            <rect x="5" y="15" width="32" height="20" rx="3" fill="#A0522D" stroke="#5D2E0C" stroke-width="1"/>
            <!-- Right cushion -->
            <rect x="38" y="15" width="32" height="20" rx="3" fill="#A0522D" stroke="#5D2E0C" stroke-width="1"/>
            <!-- Outer armrests -->
            <rect x="2" y="15" width="3" height="15" rx="1" fill="#6B3410"/>
            <rect x="70" y="15" width="3" height="15" rx="1" fill="#6B3410"/>
            <!-- Center armrest -->
            <rect x="36" y="15" width="3" height="12" rx="1" fill="#6B3410"/>
        </svg>
    `
};

// ====================================
// ROW & COLUMN MANAGEMENT
// ====================================

class TheatreSeating {
    constructor(config = {}) {
        this.config = {
            rows: config.rows || 10,
            columns: config.columns || 20,
            aisleColumns: config.aisleColumns || [10], // Column numbers where aisles appear
            rowLabels: config.rowLabels || 'letters', // 'letters' or 'numbers'
            columnLabels: config.columnLabels || 'numbers', // 'numbers' or 'letters'
            prices: config.prices || {
                standard: 25,
                premium: 35,
                vip: 50,
                wheelchair: 25
            },
            vipRows: config.vipRows || [0, 1, 2], // First 3 rows are VIP
            wheelchairSeats: config.wheelchairSeats || ['A1', 'A20', 'J1', 'J20']
        };
        
        this.seats = this.initializeSeats();
        this.selectedSeats = [];
        this.soldSeats = [];
    }

    // Generate row label (A-Z, AA-ZZ, etc.)
    getRowLabel(index) {
        if (this.config.rowLabels === 'numbers') {
            return (index + 1).toString();
        }
        
        let label = '';
        let num = index;
        while (num >= 0) {
            label = String.fromCharCode(65 + (num % 26)) + label;
            num = Math.floor(num / 26) - 1;
        }
        return label;
    }

    // Initialize all seats
    initializeSeats() {
        const seats = [];
        
        for (let row = 0; row < this.config.rows; row++) {
            const rowLabel = this.getRowLabel(row);
            
            for (let col = 1; col <= this.config.columns; col++) {
                const seatId = `${rowLabel}${col}`;
                const seat = {
                    id: seatId,
                    row: rowLabel,
                    rowIndex: row,
                    column: col,
                    type: this.getSeatType(row, seatId),
                    status: 'available', // available, selected, sold, reserved
                    price: this.getSeatPrice(row, seatId)
                };
                seats.push(seat);
            }
        }
        
        return seats;
    }

    // Determine seat type
    getSeatType(rowIndex, seatId) {
        if (this.config.wheelchairSeats.includes(seatId)) {
            return 'wheelchair';
        }
        if (this.config.vipRows.includes(rowIndex)) {
            return 'vip';
        }
        return 'standard';
    }

    // Get seat price
    getSeatPrice(rowIndex, seatId) {
        const type = this.getSeatType(rowIndex, seatId);
        return this.config.prices[type] || this.config.prices.standard;
    }

    // Get seat by ID
    getSeat(seatId) {
        return this.seats.find(seat => seat.id === seatId);
    }

    // Select seat
    selectSeat(seatId) {
        const seat = this.getSeat(seatId);
        if (!seat || seat.status !== 'available') {
            return { success: false, message: 'Seat not available' };
        }
        
        seat.status = 'selected';
        this.selectedSeats.push(seatId);
        return { success: true, seat };
    }

    // Deselect seat
    deselectSeat(seatId) {
        const seat = this.getSeat(seatId);
        if (!seat || seat.status !== 'selected') {
            return { success: false };
        }
        
        seat.status = 'available';
        this.selectedSeats = this.selectedSeats.filter(id => id !== seatId);
        return { success: true };
    }

    // Get seats by row
    getSeatsByRow(rowLabel) {
        return this.seats.filter(seat => seat.row === rowLabel);
    }

    // Get seats by column
    getSeatsByColumn(columnNumber) {
        return this.seats.filter(seat => seat.column === columnNumber);
    }

    // Get available seats
    getAvailableSeats() {
        return this.seats.filter(seat => seat.status === 'available');
    }

    // Calculate total price of selected seats
    getSelectedTotal() {
        return this.selectedSeats.reduce((total, seatId) => {
            const seat = this.getSeat(seatId);
            return total + (seat ? seat.price : 0);
        }, 0);
    }

    // Export seating data as JSON
    exportData() {
        return {
            config: this.config,
            seats: this.seats,
            selectedSeats: this.selectedSeats,
            soldSeats: this.soldSeats,
            stats: {
                totalSeats: this.seats.length,
                available: this.seats.filter(s => s.status === 'available').length,
                selected: this.selectedSeats.length,
                sold: this.soldSeats.length
            }
        };
    }
}

// ====================================
// HTML GENERATION
// ====================================

function generateTheatreHTML(theatre) {
    let html = '<div class="theatre-layout">';
    
    const rows = {};
    theatre.seats.forEach(seat => {
        if (!rows[seat.row]) rows[seat.row] = [];
        rows[seat.row].push(seat);
    });

    Object.keys(rows).forEach(rowLabel => {
        html += `<div class="seat-row" data-row="${rowLabel}">`;
        html += `<div class="row-label">${rowLabel}</div>`;
        html += '<div class="seats-container">';
        
        rows[rowLabel].forEach((seat, index) => {
            // Add aisle if needed
            if (theatre.config.aisleColumns.includes(seat.column)) {
                html += '<div class="aisle"></div>';
            }
            
            const statusClass = seat.status;
            const typeClass = seat.type;
            
            html += `
                <div class="seat ${statusClass} ${typeClass}" 
                     data-seat-id="${seat.id}"
                     data-row="${seat.row}"
                     data-column="${seat.column}"
                     data-price="${seat.price}"
                     onclick="handleSeatClick('${seat.id}')">
                    <span class="seat-number">${seat.column}</span>
                </div>
            `;
        });
        
        html += '</div></div>';
    });
    
    html += '</div>';
    return html;
}

// ====================================
// INTEGRATION EXAMPLES
// ====================================

// Example 1: Basic Integration
function basicIntegration() {
    const theatre = new TheatreSeating({
        rows: 12,
        columns: 24,
        aisleColumns: [6, 18],
        vipRows: [0, 1, 2]
    });

    const container = document.getElementById('seating-chart');
    container.innerHTML = generateTheatreHTML(theatre);

    window.handleSeatClick = function(seatId) {
        const seat = theatre.getSeat(seatId);
        
        if (seat.status === 'available') {
            theatre.selectSeat(seatId);
        } else if (seat.status === 'selected') {
            theatre.deselectSeat(seatId);
        }
        
        updateUI(theatre);
    };
}

// Example 2: With Backend Integration
async function bookSeats(theatre) {
    const selectedSeats = theatre.selectedSeats;
    
    try {
        const response = await fetch('/api/seats/reserve', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                seats: selectedSeats,
                totalPrice: theatre.getSelectedTotal(),
                timestamp: new Date().toISOString()
            })
        });
        
        const result = await response.json();
        
        if (result.success) {
            // Mark seats as sold
            selectedSeats.forEach(seatId => {
                const seat = theatre.getSeat(seatId);
                seat.status = 'sold';
                theatre.soldSeats.push(seatId);
            });
            theatre.selectedSeats = [];
            return { success: true, bookingId: result.bookingId };
        }
    } catch (error) {
        console.error('Booking failed:', error);
        return { success: false, error: error.message };
    }
}

// Example 3: Export to SVG
function exportToSVG(theatre) {
    const rowHeight = 50;
    const seatWidth = 45;
    const seatHeight = 45;
    const aisleWidth = 40;
    
    let svgWidth = 0;
    const svgHeight = theatre.config.rows * rowHeight + 100;
    
    // Calculate width including aisles
    svgWidth = theatre.config.columns * seatWidth + 
               theatre.config.aisleColumns.length * aisleWidth + 100;
    
    let svg = `<svg width="${svgWidth}" height="${svgHeight}" xmlns="http://www.w3.org/2000/svg">`;
    
    // Add stage
    svg += `<rect x="50" y="10" width="${svgWidth - 100}" height="40" fill="#2c3e50" rx="5"/>`;
    svg += `<text x="${svgWidth/2}" y="35" text-anchor="middle" fill="white" font-size="18" font-weight="bold">STAGE</text>`;
    
    // Add seats
    let yPos = 70;
    const rows = {};
    theatre.seats.forEach(seat => {
        if (!rows[seat.row]) rows[seat.row] = [];
        rows[seat.row].push(seat);
    });
    
    Object.keys(rows).forEach(rowLabel => {
        let xPos = 50;
        
        // Row label
        svg += `<text x="30" y="${yPos + 25}" font-weight="bold" font-size="16">${rowLabel}</text>`;
        
        rows[rowLabel].forEach(seat => {
            // Add aisle space
            if (theatre.config.aisleColumns.includes(seat.column)) {
                xPos += aisleWidth;
            }
            
            // Seat color based on status and type
            let color = '#4CAF50'; // available
            if (seat.status === 'selected') color = '#FFC107';
            if (seat.status === 'sold') color = '#F44336';
            if (seat.type === 'vip') color = '#9C27B0';
            
            svg += `<rect x="${xPos}" y="${yPos}" width="${seatWidth - 5}" height="${seatHeight - 5}" 
                    fill="${color}" rx="5" stroke="#333" stroke-width="1"/>`;
            svg += `<text x="${xPos + 20}" y="${yPos + 25}" text-anchor="middle" fill="white" 
                    font-size="12" font-weight="bold">${seat.column}</text>`;
            
            xPos += seatWidth;
        });
        
        yPos += rowHeight;
    });
    
    svg += '</svg>';
    return svg;
}

// ====================================
// UTILITY FUNCTIONS
// ====================================

// Get best available seats (center, front)
function getBestAvailableSeats(theatre, quantity) {
    const available = theatre.getAvailableSeats();
    const centerCol = Math.floor(theatre.config.columns / 2);
    
    // Sort by: distance from center, then row (prefer middle rows)
    const sorted = available.sort((a, b) => {
        const aDistFromCenter = Math.abs(a.column - centerCol);
        const bDistFromCenter = Math.abs(b.column - centerCol);
        const aDistFromMiddleRow = Math.abs(a.rowIndex - theatre.config.rows / 2);
        const bDistFromMiddleRow = Math.abs(b.rowIndex - theatre.config.rows / 2);
        
        if (aDistFromCenter !== bDistFromCenter) {
            return aDistFromCenter - bDistFromCenter;
        }
        return aDistFromMiddleRow - bDistFromMiddleRow;
    });
    
    return sorted.slice(0, quantity);
}

// Find consecutive seats in a row
function findConsecutiveSeats(theatre, rowLabel, quantity) {
    const rowSeats = theatre.getSeatsByRow(rowLabel)
        .filter(seat => seat.status === 'available')
        .sort((a, b) => a.column - b.column);
    
    for (let i = 0; i <= rowSeats.length - quantity; i++) {
        const consecutive = rowSeats.slice(i, i + quantity);
        const isConsecutive = consecutive.every((seat, idx) => {
            if (idx === 0) return true;
            return seat.column === consecutive[idx - 1].column + 1;
        });
        
        if (isConsecutive) {
            return consecutive;
        }
    }
    
    return [];
}

// ====================================
// EXPORT
// ====================================

if (typeof module !== 'undefined' && module.exports) {
    module.exports = {
        TheatreSeating,
        SEAT_DESIGNS,
        generateTheatreHTML,
        exportToSVG,
        getBestAvailableSeats,
        findConsecutiveSeats
    };
}
