# 🎭 Theatre Seating System - Complete Guide
## Rows & Columns for Cinema, Auditorium & Theatre Venues

---

## 📦 What You Have

### **3 Complete Files:**

1. **theatre-seating-system.html** - Full interactive seating chart
2. **theatre-seating-components.js** - Reusable components and API
3. **theatre-seating-README.md** - This documentation

---

## 🎯 Features

### **✅ Theatre-Style Layout**
- Rows labeled A-Z (or numbers)
- Columns numbered 1-N
- Automatic row/column labeling
- Configurable aisles
- Multiple seat types (Standard, VIP, Wheelchair, Loveseat)

### **✅ Seat Management**
- Real-time seat selection
- Status tracking (Available, Selected, Sold, Reserved)
- Price tiers (Standard $25, Premium $35, VIP $50)
- Shopping cart integration
- Multiple seat selection

### **✅ Professional Features**
- Responsive design (mobile-ready)
- SVG export capability
- Database integration ready
- Backend API examples
- Real-time updates support

---

## 🚀 Quick Start

### **Option 1: Use the Complete System**
```html
<!-- Simply open theatre-seating-system.html in a browser -->
<!-- Customize rows, columns, and aisles using the controls -->
```

### **Option 2: Integrate Components**
```javascript
import { TheatreSeating } from './theatre-seating-components.js';

// Create theatre with 10 rows, 20 columns
const theatre = new TheatreSeating({
    rows: 10,
    columns: 20,
    aisleColumns: [10],  // Aisle after column 10
    vipRows: [0, 1, 2]   // First 3 rows are VIP
});

// Generate HTML
const html = generateTheatreHTML(theatre);
document.getElementById('seating-area').innerHTML = html;
```

---

## 🎨 Understanding Rows & Columns

### **Row Labeling**
```
A = Row 1
B = Row 2
C = Row 3
...
Z = Row 26
AA = Row 27
AB = Row 28
```

**Example: 10 rows = A through J**

### **Column Numbering**
```
Columns: 1, 2, 3, 4, ... N
```

**Example: 20 columns = 1 through 20**

### **Seat ID Format**
```
[ROW][COLUMN]

Examples:
- A1 = Row A, Seat 1 (Front left)
- A10 = Row A, Seat 10 (Front center-left)
- J20 = Row J, Seat 20 (Back right)
- D15 = Row D, Seat 15 (Middle section)
```

---

## 💻 Configuration Options

### **Basic Configuration**
```javascript
const theatre = new TheatreSeating({
    rows: 12,              // Number of rows (A-L)
    columns: 24,           // Seats per row (1-24)
    aisleColumns: [6, 18], // Aisles after columns 6 and 18
    rowLabels: 'letters',  // 'letters' (A-Z) or 'numbers' (1-N)
    columnLabels: 'numbers' // Always numbers for columns
});
```

### **Advanced Configuration**
```javascript
const theatre = new TheatreSeating({
    rows: 15,
    columns: 30,
    aisleColumns: [10, 20],      // Two aisles (3 sections)
    vipRows: [0, 1, 2, 3],       // First 4 rows are VIP
    wheelchairSeats: ['A1', 'A30', 'O1', 'O30'], // Accessible seats
    prices: {
        standard: 25,
        premium: 35,
        vip: 50,
        wheelchair: 25
    }
});
```

---

## 🏗️ Aisle Configuration

### **Understanding Aisles**
Aisles divide columns into sections for easy access.

**Single Aisle (Center):**
```javascript
aisleColumns: [10]  // Aisle after column 10

Result:
[1 2 3 4 5 6 7 8 9 10] [AISLE] [11 12 13 14 15 16 17 18 19 20]
```

**Double Aisles (3 Sections):**
```javascript
aisleColumns: [8, 16]  // Aisles after columns 8 and 16

Result:
[1-8] [AISLE] [9-16] [AISLE] [17-24]
```

**Triple Aisles (4 Sections):**
```javascript
aisleColumns: [6, 12, 18]

Result:
[1-6] [AISLE] [7-12] [AISLE] [13-18] [AISLE] [19-24]
```

---

## 🎫 Seat Types & Pricing

### **Seat Type Hierarchy**

```javascript
// 1. Standard Seat - $25
{
    id: 'E10',
    type: 'standard',
    price: 25
}

// 2. VIP Seat - $50 (front rows)
{
    id: 'A10',
    type: 'vip',
    price: 50
}

// 3. Wheelchair Space - $25 (accessible)
{
    id: 'A1',
    type: 'wheelchair',
    price: 25
}

// 4. Premium Seat - $35 (custom)
{
    id: 'F12',
    type: 'premium',
    price: 35
}
```

### **Setting VIP Rows**
```javascript
// Make first 3 rows VIP
vipRows: [0, 1, 2]  // Row indices (A=0, B=1, C=2)

// Make last 2 rows VIP
vipRows: [8, 9]     // For 10-row theatre (I=8, J=9)

// Make middle rows VIP
vipRows: [4, 5, 6]  // Rows E, F, G
```

---

## 📊 Common Theatre Layouts

### **Small Theatre (100 seats)**
```javascript
rows: 10        // A-J
columns: 10     // 1-10
aisleColumns: [5]
Total: 10 × 10 = 100 seats
```

### **Medium Cinema (250 seats)**
```javascript
rows: 12        // A-L
columns: 20     // 1-20
aisleColumns: [10]
Total: 12 × 20 = 240 seats
```

### **Large Auditorium (500 seats)**
```javascript
rows: 20        // A-T
columns: 30     // 1-30
aisleColumns: [10, 20]
Total: 20 × 30 = 600 seats
```

### **IMAX Style (400 seats)**
```javascript
rows: 15        // A-O
columns: 28     // 1-28
aisleColumns: [7, 14, 21]
Total: 15 × 28 = 420 seats
```

---

## 🔧 Working with Rows & Columns

### **Get All Seats in a Row**
```javascript
// Get all seats in row D
const rowD = theatre.getSeatsByRow('D');

console.log(rowD);
// Output: [
//   { id: 'D1', row: 'D', column: 1, ... },
//   { id: 'D2', row: 'D', column: 2, ... },
//   ...
// ]
```

### **Get All Seats in a Column**
```javascript
// Get all seats in column 10
const column10 = theatre.getSeatsByColumn(10);

console.log(column10);
// Output: [
//   { id: 'A10', row: 'A', column: 10, ... },
//   { id: 'B10', row: 'B', column: 10, ... },
//   ...
// ]
```

### **Find Specific Seat**
```javascript
const seat = theatre.getSeat('E12');

console.log(seat);
// Output: {
//   id: 'E12',
//   row: 'E',
//   rowIndex: 4,
//   column: 12,
//   type: 'standard',
//   status: 'available',
//   price: 25
// }
```

---

## 🛒 Seat Selection & Cart

### **Select a Seat**
```javascript
// User clicks seat C5
const result = theatre.selectSeat('C5');

if (result.success) {
    console.log('Seat selected:', result.seat);
    updateCart();
} else {
    alert(result.message); // "Seat not available"
}
```

### **Deselect a Seat**
```javascript
theatre.deselectSeat('C5');
updateCart();
```

### **Get Selected Seats**
```javascript
console.log(theatre.selectedSeats);
// Output: ['C5', 'C6', 'D10']

const total = theatre.getSelectedTotal();
console.log('Total:', total); // $75.00
```

### **Find Consecutive Seats**
```javascript
// Find 4 consecutive seats in row E
const seats = findConsecutiveSeats(theatre, 'E', 4);

if (seats.length === 4) {
    console.log('Found:', seats.map(s => s.id));
    // Example: ['E8', 'E9', 'E10', 'E11']
}
```

---

## 💾 Database Integration

### **Database Schema**
```sql
CREATE TABLE theatre_seats (
    id VARCHAR(10) PRIMARY KEY,          -- e.g., 'A1', 'B10'
    theatre_id INT NOT NULL,
    row_label VARCHAR(5) NOT NULL,       -- 'A', 'B', 'C'
    row_index INT NOT NULL,              -- 0, 1, 2
    column_number INT NOT NULL,          -- 1, 2, 3
    seat_type ENUM('standard', 'vip', 'wheelchair', 'premium'),
    status ENUM('available', 'selected', 'sold', 'reserved'),
    price DECIMAL(10,2) NOT NULL,
    customer_id INT,
    booking_id VARCHAR(50),
    reserved_at TIMESTAMP,
    sold_at TIMESTAMP,
    INDEX idx_theatre_status (theatre_id, status),
    INDEX idx_row_col (row_label, column_number)
);

CREATE TABLE bookings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    booking_id VARCHAR(50) UNIQUE,
    customer_email VARCHAR(255),
    seats JSON,                          -- ['A1', 'A2', 'A3']
    total_price DECIMAL(10,2),
    status ENUM('pending', 'confirmed', 'cancelled'),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

### **Backend API (Node.js/Express)**
```javascript
const express = require('express');
const app = express();

// Get available seats
app.get('/api/theatre/:theatreId/seats', async (req, res) => {
    const seats = await db.query(
        'SELECT * FROM theatre_seats WHERE theatre_id = ? AND status = "available"',
        [req.params.theatreId]
    );
    res.json(seats);
});

// Get specific row
app.get('/api/theatre/:theatreId/row/:rowLabel', async (req, res) => {
    const seats = await db.query(
        'SELECT * FROM theatre_seats WHERE theatre_id = ? AND row_label = ? ORDER BY column_number',
        [req.params.theatreId, req.params.rowLabel]
    );
    res.json(seats);
});

// Reserve seats
app.post('/api/seats/reserve', async (req, res) => {
    const { seats, customerEmail } = req.body;
    
    try {
        await db.transaction(async (trx) => {
            // Check all seats are available
            for (const seatId of seats) {
                const seat = await trx('theatre_seats')
                    .where('id', seatId)
                    .where('status', 'available')
                    .forUpdate()
                    .first();
                
                if (!seat) {
                    throw new Error(`Seat ${seatId} not available`);
                }
            }
            
            // Reserve all seats
            await trx('theatre_seats')
                .whereIn('id', seats)
                .update({
                    status: 'reserved',
                    reserved_at: new Date()
                });
            
            // Create booking
            const bookingId = generateBookingId();
            await trx('bookings').insert({
                booking_id: bookingId,
                customer_email: customerEmail,
                seats: JSON.stringify(seats),
                status: 'pending'
            });
            
            res.json({ success: true, bookingId });
        });
    } catch (error) {
        res.status(400).json({ success: false, error: error.message });
    }
});
```

---

## 🎨 Customizing Seat Colors

### **CSS Classes**
```css
/* Available seats - Green */
.seat.available {
    background: #4CAF50;
}

/* Selected seats - Yellow */
.seat.selected {
    background: #FFC107;
    box-shadow: 0 4px 12px rgba(255, 193, 7, 0.5);
}

/* Sold seats - Red */
.seat.sold {
    background: #F44336;
    cursor: not-allowed;
    opacity: 0.7;
}

/* VIP seats - Purple */
.seat.vip {
    background: #9C27B0;
}

/* Wheelchair spaces - Blue */
.seat.wheelchair {
    background: #2196F3;
    border: 2px dashed #1976D2;
}
```

---

## 📱 Mobile Responsive

```css
@media (max-width: 768px) {
    /* Adjust seat size */
    .seat {
        width: 35px;
        height: 35px;
        font-size: 0.75em;
    }
    
    /* Make scrollable */
    .seating-area {
        overflow-x: auto;
        -webkit-overflow-scrolling: touch;
    }
    
    /* Stack controls */
    .controls {
        flex-direction: column;
    }
}
```

---

## 📤 Export Functions

### **Export to JSON**
```javascript
const data = theatre.exportData();

console.log(data);
// Output: {
//   config: { rows: 10, columns: 20, ... },
//   seats: [ { id: 'A1', ... }, ... ],
//   selectedSeats: ['C5', 'C6'],
//   soldSeats: ['A1', 'A2'],
//   stats: {
//     totalSeats: 200,
//     available: 195,
//     selected: 2,
//     sold: 3
//   }
// }
```

### **Export to SVG**
```javascript
const svg = exportToSVG(theatre);

// Save to file
const blob = new Blob([svg], { type: 'image/svg+xml' });
const url = URL.createObjectURL(blob);
const a = document.createElement('a');
a.href = url;
a.download = 'seating-chart.svg';
a.click();
```

---

## 🧠 Smart Features

### **Find Best Available Seats**
```javascript
// Get 4 best seats (center, middle rows)
const bestSeats = getBestAvailableSeats(theatre, 4);

console.log(bestSeats.map(s => s.id));
// Example: ['F11', 'F12', 'F13', 'F14']
```

### **Auto-Select Consecutive Seats**
```javascript
// Try to find 5 consecutive seats
for (let row of ['D', 'E', 'F', 'G']) {
    const seats = findConsecutiveSeats(theatre, row, 5);
    if (seats.length === 5) {
        seats.forEach(seat => theatre.selectSeat(seat.id));
        break;
    }
}
```

---

## ⚡ Real-Time Updates (WebSockets)

```javascript
// Server (Node.js)
const io = require('socket.io')(server);

io.on('connection', (socket) => {
    // Join theatre room
    socket.on('join-theatre', (theatreId) => {
        socket.join(`theatre-${theatreId}`);
    });
    
    // Broadcast seat selection
    socket.on('seat-selected', (data) => {
        socket.broadcast.to(`theatre-${data.theatreId}`)
            .emit('seat-unavailable', data.seatId);
    });
});

// Client
const socket = io();
socket.emit('join-theatre', theatreId);

socket.on('seat-unavailable', (seatId) => {
    // Update UI
    const seat = theatre.getSeat(seatId);
    seat.status = 'reserved';
    updateSeatElement(seatId);
});
```

---

## 📊 Analytics & Reporting

### **Popular Seats Heatmap**
```javascript
async function generateHeatmap(theatreId) {
    const data = await fetch(`/api/analytics/${theatreId}/popular-seats`);
    const popularSeats = await data.json();
    
    // Color seats by popularity (green = less popular, red = most popular)
    popularSeats.forEach(({ seatId, bookingCount }) => {
        const element = document.querySelector(`[data-seat-id="${seatId}"]`);
        const opacity = bookingCount / maxBookings;
        element.style.background = `rgba(255, 0, 0, ${opacity})`;
    });
}
```

### **Row/Column Statistics**
```javascript
// Analyze which rows sell best
const rowStats = {};
theatre.soldSeats.forEach(seatId => {
    const row = seatId.match(/[A-Z]+/)[0];
    rowStats[row] = (rowStats[row] || 0) + 1;
});

console.log(rowStats);
// Output: { A: 20, B: 18, C: 15, ... }
```

---

## 🧪 Testing Checklist

- [ ] Rows labeled correctly (A-Z)
- [ ] Columns numbered correctly (1-N)
- [ ] Aisles appear in correct positions
- [ ] Seat selection works
- [ ] Multiple selections work
- [ ] Cannot select sold seats
- [ ] VIP rows priced correctly
- [ ] Wheelchair spaces marked
- [ ] Cart total calculates correctly
- [ ] Mobile responsive
- [ ] SVG export works
- [ ] Database integration works

---

## 🆘 Troubleshooting

### **Rows not labeled correctly?**
Check `rowLabels` config:
```javascript
rowLabels: 'letters'  // A, B, C...
// OR
rowLabels: 'numbers'  // 1, 2, 3...
```

### **Aisles in wrong position?**
Aisles appear AFTER the column number:
```javascript
aisleColumns: [10]  // Aisle after column 10, before column 11
```

### **Seats overlapping?**
Adjust seat dimensions and gaps:
```css
.seat {
    width: 40px;
    height: 40px;
    margin: 2px;
}
```

---

## 🎉 You're Ready!

You now have a complete theatre seating system with:
- ✅ Configurable rows and columns
- ✅ Flexible aisle positioning
- ✅ Multiple seat types
- ✅ Shopping cart functionality
- ✅ Database integration
- ✅ Export capabilities
- ✅ Mobile responsive design

### **Next Steps:**
1. Open `theatre-seating-system.html` to test
2. Configure rows, columns, and aisles
3. Integrate with your backend
4. Customize colors and styles
5. Deploy to production!

---

## 💡 Support

All code is fully commented and production-ready. The system supports:
- Any number of rows (A-Z, AA-ZZ, etc.)
- Any number of columns (1-N)
- Multiple aisles
- Multiple seat types
- Multiple pricing tiers
- Real-time availability
- Mobile devices

Good luck with your theatre ticketing system! 🎫🎭
